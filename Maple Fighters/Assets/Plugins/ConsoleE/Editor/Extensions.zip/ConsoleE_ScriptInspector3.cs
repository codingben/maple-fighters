/*
 * This file shows how to integrate Script Inspector 3 with ConsoleE so that files will be opened in Script Inspector 3.
 * 
 * This only works with ConsoleE Pro.
 * 
 */
#if !MRKCUR && !DEV_BUILD // from Mark (developer): I don't compile unless I'm expliciting testing with Script Inspector 3

using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using ScriptInspector;

#if !UNITY_EDITOR
#error An extension for ConsoleE is being compiled in non-editor build, ConsoleE is an editor-only extension
#endif

namespace ConsoleE
{
	/// <summary>
	/// Integrates Script Inspector 3 with ConsoleE so that files will be opened in Script Inspector 3.  This only works with ConsoleE Pro.
	/// </summary>
	[InitializeOnLoad]
	public class ConsoleE_Extensions
	{
		static ConsoleE_Extensions()
		{
			// every time you press Run, hooks need to be resync-ed with ConsoleE.
			// with [InitializeOnLoad], this register step will occur whenever you press play
			// only += is needed, no need for -= later
			// most "ConsoleE.Api.onXXXX" events require ConsoleE Pro
			// note that Unity calls [InitializeOnLoad] very early during initialization. The ConsoleE window is not yet initialized. Many ConsoleE.Api functions will not work until a little later.
			ConsoleE.Api.onClick += OnClick;   // event is triggered when user tries to open a file
		}

		/// <summary>
		/// Called whenever a file is about to be opened by the console.  In this method, you have the option of overriding the open file behavior.
		/// Requires ConsoleE PRO.
		/// </summary>
		/// <param name="p">If p.OpenUsingDefaultMethod is true, ConsoleE will open the file normally.  If false, ConsoleE will no nothing.
		/// p.windowArea describes if the click ocurred in the main area or in the callstack.
		/// p.logEntry contains info about the selected log entry. If multi entries are selected, p.logEntry is null.
		/// p.logEntry.tabCategory is the tab category for the log item clicked.
		/// p.logEntry.rows are the rows of the log entry. Rows[0] is the Log msg, the rest is the callstack.
		/// p.filename is filename that should be open (considering wrapper list).
		/// p.externalEditorPath if user used "Open with", this indicates which editor should be used to open the file.
		/// p.indexOpenWithOption if user used "Open with, this is the index of the menu item in "Open with" that was clicked.
		/// p.indexRowSelected, which callstack row was clicked, or -1 if none.
		/// </param>
		/// <returns></returns>
		static public void OnClick(OnClickParams p)
		{
			if(p.filename == null) // if failed to parse filename
			{
				p.openUsingDefaultMethod = true;
				return;
			}

			string relativePath = FilenameRelativeToAssets(p.filename);

			var guid = AssetDatabase.AssetPathToGUID(relativePath);

			if(string.IsNullOrEmpty(guid))
			{
				p.openUsingDefaultMethod = true; // true if not handled in which case ConsoleE will open the file using the default code, set to false if you do not want ConsoleE to open the file
			}
			else
			{
				// open in Script Inspector 3
				//  Script Inspector 3 needs Event.current to be non-null, so open the file during a render event
				ConsoleE.Api.InvokeAfterNextRender(true, ()=> { FGCodeWindow.OpenAssetInTab(guid, p.lineNumber); } );
			}
		}

		static string FilenameRelativeToAssets(string filename)
		{
			string prefix = Application.dataPath;
			if (filename.StartsWith(prefix))
			{
				filename = "Assets" + filename.Substring(prefix.Length).Replace(System.IO.Path.AltDirectorySeparatorChar, System.IO.Path.DirectorySeparatorChar);
			}
			return filename;
		}
	}
}

#endif